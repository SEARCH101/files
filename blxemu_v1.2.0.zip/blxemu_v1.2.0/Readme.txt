
Password to open the archive: 123abc


If you cannot open the .rar archive, download WinRar software for free: 
https://www.win-rar.com/download.html